# SA Calculator v98.42 — Release hygiene and CSS consolidation

## Verified weaknesses corrected
- Replaced nine render-blocking stylesheet links with one production CSS bundle, preserving the previous cascade order exactly.
- Kept original CSS source layers as build inputs; `prepare-android-web.mjs` regenerates the production bundle before Android copy.
- Reduced service-worker CSS precache to the actual single production stylesheet; removed the unused v98.36 stylesheet from the runtime precache list.
- Removed stale v98.40/v98.41 root workflow copies and older duplicate workflow aliases. There is one active workflow and one downloadable release YAML copy.
- Renamed release identity consistently to v98.42 and Android versionCode 1098042.
- Replaced stale README instructions with current release/build/validation guidance.

## Preserved
Calculator parser and arithmetic, all registered screen IDs, scientific dialog/mode, currency rate provider and freshness logic, unit conversions, tool calculations, theme system, settings, history, favorites, Android branding and safe-area behavior.

## Validation scope
Node automated tests, JavaScript syntax, generated web bundle, stylesheet source order, YAML parse and ZIP integrity are checked. Hosted APK build and physical-device visual/performance testing remain external release gates.
