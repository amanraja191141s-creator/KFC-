# SA Calculator v98.49 — Scientific Calculator Reference Layout

This release rebuilds the independent Scientific Calculator screen around the supplied reference: natural expression/result display, DEG/RAD and memory indicators, history/More controls, SHIFT/DRG/cursor/delete/AC toolbar, six-column scientific function bank, dedicated memory row, and five-column four-row numeric keypad. Scientific functions are limited to operations implemented by the expression engine; unsupported symbolic calculus, matrices, complex arithmetic and graphing are not presented as working controls.

## Build
- `npm test`
- `npm run build:web`
- GitHub Actions workflow: `SA-Calculator-v98.49-Android-Workflow.yml`

The ZIP contains source and the generated Android `www` web bundle. A hosted APK build and physical-device validation must still be run in GitHub Actions/on-device.


## Follow-up UI polish
The source includes the v98.50 correction layer (`assets/css/rebuild-v98.50.css`) and regression tests for the requested header/navigation/keypad/converter/scientific-display changes. Run `npm test` and `npm run build:web` before release. Package identity remains v98.49 to preserve the supplied workflow's exact source-selection contract; this is a follow-up source polish, not a newly versioned Android release.
