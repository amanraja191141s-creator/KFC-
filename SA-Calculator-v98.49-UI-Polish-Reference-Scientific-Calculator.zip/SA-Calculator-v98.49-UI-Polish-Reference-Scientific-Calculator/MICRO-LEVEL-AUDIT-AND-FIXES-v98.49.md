# v98.49 Micro-Level Audit and Fixes

## Reference-derived requirements
- Natural expression and result area with a compact top status line.
- DEG/RAD and memory state indicators.
- History and More actions.
- Dedicated edit strip for SHIFT, angle toggle, cursor movement, delete and AC.
- Six-column scientific function layout, separate memory row, five-column numeric/operator keypad.

## Implemented
- Independent screen markup and CSS; no modal dependency.
- SHIFT swaps sin/cos/tan to inverse trig, log to log₂, and ln to eˣ.
- DRG toggles DEG/RAD and persists the scientific angle mode.
- Cursor-left/right moves the expression caret; sign toggles the selected/last numeric token.
- Memory indicator reflects scientific memory state; MC/MR/M+/M−/MS remain independent.
- History and More panels are expandable and keyboard/screen-reader labelled.
- Expression editor preserves selection/caret and horizontal scrolling.
- Responsive compact-height and narrow-screen styles retain the keypad rows.

## Deliberately not represented as functional
The reference image includes complex-number `i`, matrices, summation, integral, derivative, camera/OCR, base conversion and symbolic algebra. The current evaluator does not implement these systems. They are not exposed as fake working buttons. They require separate engines and validation before being added.

## External research comparison
HiPER lists fractions, equations, matrices, vectors, statistics, complex numbers, integrals/derivatives, graphing, bases and RPN; another scientific calculator lists complex/matrix support and numeric calculus; Google Android accessibility guidance recommends at least 48dp touch targets. This release implements only the subset supported by the existing parser and marks the remaining items as future work.

## Validation boundary
Source tests, JavaScript syntax, YAML parsing, ZIP integrity and generated web-bundle checks can be run locally. Android SDK/Gradle hosted build and physical-device touch/render/performance validation remain pending.


## Follow-up UI corrections
- The in-app app-header is now removed; OS status and navigation bars remain untouched.
- Settings is now a first-class bottom destination rather than sharing the Tools active state.
- Bottom navigation is hidden for calculator/converter detail screens and shown for Calculator, Favorites, Tools and Settings.
- Basic keypad key visuals are slightly reduced while touch targets remain at least 48px.
- Currency/unit selectors retain their native selected-value model; selected labels are ellipsized and no option names are copied into numeric keypads.
- Scientific display expression/result sizing is tuned for short and narrow screens. Device-level rendering still requires Android validation.
