const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
test('v98.27 release identity is consistent across runtime, manifest, HTML and cache', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const sw = read('service-worker.js');
  assert.equal(pkg.version, '1.98.49-v98.49');
  assert.equal(manifest.version, pkg.version);
  assert.match(html, new RegExp(`name="sa-build-version" content="${pkg.version.replaceAll('.', '\\.')}"`));
  assert.match(html, new RegExp(pkg.version.replaceAll('.', '\\.')));
  assert.ok(js.includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(sw, /sa-calculator-v98-49-ui-correction-v9850/);
});
test('v98.27 workflow rejects stale app roots and checks exact APK identity', () => {
  const workflow = read('.github/workflows/main.yml');
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.49-v98\.49'/);
  assert.match(workflow, /Select the exact v98\.49 source archive/);
  assert.match(workflow, /versionName='1\.98\.49-v98\.49'/);
  assert.match(workflow, /versionCode='1098049'/);
  assert.match(workflow, /SA-Calculator-Debug-APK-/);
});
test('the single active workflow matches the supplied root reference copy', () => {
  assert.equal(read('SA-Calculator-v98.49-Android-Workflow.yml'), read('.github/workflows/main.yml'));
  assert.equal(fs.existsSync(path.join(root, '.github/workflows/android-apk.yml')), false);
});
